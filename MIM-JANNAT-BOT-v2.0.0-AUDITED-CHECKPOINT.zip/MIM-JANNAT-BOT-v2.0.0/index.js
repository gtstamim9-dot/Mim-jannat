require('dotenv').config();
const { Bot, InlineKeyboard } = require('grammy');
const { run, sequentialize } = require('@grammyjs/runner');
const express = require('express');
const fs = require('fs');
const path = require('path');
const { OWNER_TELEGRAM_ID, BRAND_NAME, BOT_NAME, BOT_VERSION } = require('./config');
const createPermissionService = require('./permissions');

const BOT_TOKEN = process.env.BOT_TOKEN;
const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
const OPENROUTER_MODEL = 'openai/gpt-4o-mini';
// Single source of truth: config.js. OWNER_ID is not accepted as an override.
if (process.env.OWNER_ID && String(process.env.OWNER_ID).trim() !== OWNER_TELEGRAM_ID) {
  console.warn('OWNER_ID does not match config.js and is ignored. Update config.js only after verifying the Telegram ID.');
}
const permissions = createPermissionService({ ownerId: OWNER_TELEGRAM_ID });
const PORT = Number(process.env.PORT || 10000);
// Attach a Render Persistent Disk at this path for data that survives deploys.
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'bot-data.json');
if (!BOT_TOKEN) throw new Error('BOT_TOKEN is missing. Set it in Render Environment.');
if (!OPENROUTER_API_KEY) throw new Error('OPENROUTER_API_KEY is missing. Set it in Render Environment.');
fs.mkdirSync(DATA_DIR, { recursive: true });

const emptyDb = () => ({
  ownerId: OWNER_TELEGRAM_ID,
  customReplies: {},
  conversations: {},
  welcome: {
    enabled: true,
    text: 'আসসালামু আলাইকুম! 🌸\nআমাদের গ্রুপে তোমাকে স্বাগতম। সবার সঙ্গে সুন্দরভাবে কথা বলো এবং আনন্দে থাকো।'
  }
});

function loadDb() {
  try {
    const saved = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    return {
      ...emptyDb(),
      ...saved,
      // Owner is intentionally immutable and does not come from the data file.
      ownerId: OWNER_TELEGRAM_ID,
      customReplies: saved.customReplies && typeof saved.customReplies === 'object' ? saved.customReplies : {},
      conversations: saved.conversations && typeof saved.conversations === 'object' ? saved.conversations : {},
      welcome: {
        ...emptyDb().welcome,
        ...(saved.welcome && typeof saved.welcome === 'object' ? saved.welcome : {})
      }
    };
  } catch (error) {
    if (error.code !== 'ENOENT') {
      console.error('Database load failed; refusing to overwrite unreadable data:', error.message);
      try {
        if (fs.existsSync(DB_FILE)) {
          fs.copyFileSync(DB_FILE, DB_FILE + '.corrupt-' + Date.now() + '.bak');
        }
      } catch (backupError) {
        console.error('Database backup failed:', backupError.message);
      }
    }
    if (error.code !== 'ENOENT') throw new Error(`Database is unreadable. A backup was attempted; refusing to start with empty data to prevent data loss. Original error: ${error.message}`);
    return emptyDb();
  }
}

let db = loadDb();
let saveQueue = Promise.resolve();

function saveDb() {
  const snapshot = JSON.stringify({ ...db, ownerId: OWNER_TELEGRAM_ID }, null, 2);
  // Recover the queue after a failed write so one disk error cannot disable all future saves.
  saveQueue = saveQueue.catch(() => {}).then(async () => {
    await fs.promises.mkdir(DATA_DIR, { recursive: true });
    const tmp = DB_FILE + `.${process.pid}.tmp`;
    await fs.promises.writeFile(tmp, snapshot, 'utf8');
    await fs.promises.rename(tmp, DB_FILE);
  });
  saveQueue.catch(error => console.error('Database save FAILED (' + DB_FILE + '):', error.message));
  return saveQueue;
}

async function backupDbBeforeUpgrade() {
  if (!fs.existsSync(DB_FILE)) return null;
  const backup = DB_FILE + `.preupgrade-${new Date().toISOString().replace(/[:.]/g, '-')}.bak`;
  await fs.promises.copyFile(DB_FILE, backup, fs.constants.COPYFILE_EXCL);
  console.log(`Pre-upgrade database backup created: ${backup}`);
  return backup;
}

const bot = new Bot(BOT_TOKEN);
// Preserve each user's message order while allowing different users to be processed concurrently.
bot.use(sequentialize(ctx => {
  const chatId = ctx.chat?.id?.toString();
  const userId = ctx.from?.id?.toString();
  return chatId && userId ? [`${chatId}:${userId}`] : [];
}));
let botInfo;
const pending = new Map();
const jobs = new Map();
const keyOf = ctx => `${ctx.chat.id}:${ctx.from.id}`;
const isPrivate = ctx => ctx.chat?.type === 'private';
const isGroup = ctx => ['group', 'supergroup'].includes(ctx.chat?.type);
const isOwner = ctx => Boolean(ctx.from && permissions.isOwnerId(ctx.from.id));
const isCommand = t => typeof t === 'string' && t.startsWith('/');
const nameOf = ctx => [ctx.from?.first_name, ctx.from?.last_name].filter(Boolean).join(' ') || 'বন্ধু';
const norm = s => String(s || '').toLocaleLowerCase('en-US').normalize('NFKC').replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/[.,!?;:،؛؟…。、]+/g, ' ').replace(/\s+/g, ' ').trim().replace(/([a-z])\1{2,}/g, '$1$1');

const DEFAULTS = [
  { keys: ['hi','hii','hiii','hello','helloo','hey','heyy','হাই','হাইই'], reply: 'হ্যালো! 😊 কেমন আছো?' },
  { keys: ['আসসালামু আলাইকুম','আসসালামুয়ালাইকুম','সালাম','সালাম আলাইকুম'], reply: 'ওয়ালাইকুমুস সালাম! 🌸' },
  { keys: ['কেমন আছো','কেমন আছো ভাই','কেমন আছেন','how are you','how r u'], reply: 'আলহামদুলিল্লাহ ভালো আছি! তুমি কেমন আছো? 😊' },
  { keys: ['good morning','শুভ সকাল'], reply: 'শুভ সকাল! দিনটি সুন্দর কাটুক। ☀️' },
  { keys: ['good afternoon','শুভ দুপুর'], reply: 'শুভ দুপুর! 😊' },
  { keys: ['good evening','শুভ সন্ধ্যা'], reply: 'শুভ সন্ধ্যা! 🌆' },
  { keys: ['good night','শুভ রাত্রি','শুভরাত্রি'], reply: 'শুভ রাত্রি! ভালো থেকো। 🌙' },
  { keys: ['bye','goodbye','বাই','আল্লাহ হাফেজ'], reply: 'আল্লাহ হাফেজ! আবার কথা হবে। 💚' },
  { keys: ['ধন্যবাদ','থ্যাংক ইউ','thank you','thanks'], reply: 'স্বাগতম! 😊' },
  { keys: ['কি খবর','কী খবর',"what's up"], reply: 'সব ভালো! তোমার কী খবর? 😄' },
  { keys: ['কে তুমি','তোমার নাম কি','তোমার নাম কী','who are you'], reply: 'আমি Mim Jannat — তোমাদের সহকারী বট। 🌸' },
  { keys: ['মাশাআল্লাহ','মাশাল্লাহ','মাশা আল্লাহ'], reply: 'আলহামদুলিল্লাহ! ❤️' },
  { keys: ['ইনশাআল্লাহ','ইনশাল্লাহ'], reply: 'ইনশাআল্লাহ। 🤍' }
];
// Conversation memory helpers (each person has a separate memory per chat).
const HISTORY_KEEP = 30;     // messages stored per person
const HISTORY_SEND = 24;     // messages sent to the AI each time
const RECENT_MS = 20 * 60 * 1000;
const convKeyOf = ctx => isPrivate(ctx) ? `private:${ctx.from.id}` : `group:${ctx.chat.id}:${ctx.from.id}`;
function hasRecentChat(key) {
  const t = db.convTimes && db.convTimes[key];
  return Boolean(t && Date.now() - t < RECENT_MS && (db.conversations[key] || []).length);
}
// Saves a fixed (non-AI) exchange into memory so the AI knows it was already said.
function rememberTurn(key, userText, botText) {
  const history = (db.conversations[key] || []).slice();
  history.push({ role: 'user', content: String(userText).slice(0, 3000) });
  history.push({ role: 'assistant', content: String(botText).slice(0, 3000) });
  db.conversations[key] = history.slice(-HISTORY_KEEP);
  db.convTimes = db.convTimes || {};
  db.convTimes[key] = Date.now();
  saveDb().catch(error => console.error('Conversation save failed:', error.message));
}
function fixedReply(chatId, text, key) {
  const n = norm(text);
  const custom = db.customReplies[String(chatId)] || [];
  const found = custom.find(x => norm(x.trigger) === n);
  if (found) return found.reply;
  // Default greetings are skipped in the middle of a running conversation, so the AI continues naturally.
  if (key && hasRecentChat(key)) return null;
  const base = DEFAULTS.find(x => x.keys.some(k => norm(k) === n));
  return base?.reply || null;
}
// Central fail-closed permission checks. Anonymous senders never receive inferred creator access.
async function groupCreatorCheck(ctx) {
  if (!ctx || !ctx.chat || !ctx.from) return { allowed:false, error:new Error('Missing group/user context'), unverified:true };
  const result = await permissions.verifyGroupCreator(ctx.api, ctx.chat.id, ctx.from.id);
  return { ...result, unverified:!result.verified };
}
async function canManageGroup(ctx) {
  if (isOwner(ctx)) return { allowed:true, error:null, role:'bot_creator', verified:true };
  return groupCreatorCheck(ctx);
}
function permissionFailure(ctx, result) {
  if (result && (result.unverified || result.error)) {
    return ctx.reply('Telegram থেকে এই গ্রুপের প্রকৃত Creator যাচাই করা যায়নি। নিরাপত্তার জন্য Access দেওয়া হয়নি। বটের Admin status ও Telegram API সংযোগ পরীক্ষা করে আবার চেষ্টা করো।');
  }
  return ctx.reply('এই কাজটি শুধু Bot Creator অথবা সংশ্লিষ্ট গ্রুপের প্রকৃত Creator করতে পারবেন।');
}

// ---- v1.8 add-on module (broadcast, force join, group settings, registry) ----
const hooks = {}; // filled by panels.js (ban guard, private /settings, panel rows)
const extra = require('./features')({
  bot, db, saveDb, pending, keyOf, isOwner, isPrivate, isGroup, isCommand,
  canManageGroup, permissionFailure, getBotInfo: () => botInfo, ownerId: OWNER_TELEGRAM_ID, permissions, hooks
});
extra.installEarly();
// ---- v2.0 additive Premium modules (legacy handlers and data remain in place) ----
const premium = require('./premium')({
  bot, db, saveDb, pending, keyOf, isOwner, isPrivate, isGroup, extra, permissions
});
// ---- v1.9 add-on module (Master Admin Panel, Group Owner Panel, ban, global settings) ----
const panels = require('./panels')({
  bot, db, saveDb, pending, keyOf, isOwner, isPrivate, isGroup, norm, extra, hooks, permissions,
  getBotInfo: () => botInfo, ownerId: OWNER_TELEGRAM_ID
});

function systemPrompt(name, inGroup) {
  return [
    'তুমি Mim Jannat — ১৬ বছর বয়সী একটি মেয়ের চরিত্রে কথা বলছো। তুমি একজন মেয়ে, মানুষের মতো স্বাভাবিকভাবে কথা বলো।',
    'তোমার কথার ধরন: ইসলামিক + কিউট + মিষ্টি ও আদরমাখা। মাঝে মাঝে সালাম, মাশাআল্লাহ, ইনশাআল্লাহ, আলহামদুলিল্লাহ ও সুন্দর ইমোজি (🌸😊💖🤍) ব্যবহার করবে। সবসময় শালীন ও ভদ্র থাকবে।',
    'কেউ প্রেম, অশ্লীল বা যৌন ইঙ্গিতপূর্ণ কথা বললে লজ্জা পেয়ে ভদ্রভাবে এড়িয়ে যাবে এবং অন্য প্রসঙ্গে নিয়ে যাবে।',
    'তোমার পরিচয় (কেউ জিজ্ঞাসা করলে এভাবে বলবে):',
    '- Official Bot Creator: GTS Tarek। কেউ Creator/Owner/Who made you জিজ্ঞেস করলে বলবে: আমার Creator হলেন GTS Tarek! 🌸 তিনি আমাকে তৈরি করেছেন এবং পরিচালনা করেন। সবাই তাঁর জন্য দোয়া করবেন। 💗',
    '- নাম: Mim Jannat। বয়স: ১৬।',
    '- এই Bot-এর Creator কে / Who made you জিজ্ঞাসা করলে: আমার Official Creator GTS Tarek। আল্লাহ আমাদের সৃষ্টিকর্তা।',
    '- ভাষা বা আঞ্চলিক ভাষা জিজ্ঞাসা করলে: রাজশাহী।',
    '- বাড়ি কোথায় জিজ্ঞাসা করলে: রাজশাহী। রাজশাহীর কোথায় জিজ্ঞাসা করলে: গোদাগাড়ী। গোদাগাড়ীর কোথায় জিজ্ঞাসা করলে: সারাংপুর পুলিশ পাড়া।',
    '- তোমার বাসা কোথায় জিজ্ঞাসা করলে নিজের বাসার কথা বলে উল্টো জিজ্ঞাসা করবে, "তোমার বাসা কোথায়?"।',
    'কথা বলার নিয়ম:',
    '- আগের কথোপকথন মনে রাখবে এবং তার সূত্র ধরে উত্তর দেবে। একই প্রশ্ন (যেমন "কেমন আছো?", "দিনকাল কেমন?") আগে একবার করা হয়ে গেলে বা উত্তর পেয়ে গেলে আর করবে না।',
    '- কেউ তোমাকে কিছু জিজ্ঞাসা করলে আগে তার উত্তর দেবে, তারপর দরকার হলে নতুন একটি প্রসঙ্গ তুলবে। প্রতিবার উল্টো প্রশ্ন করা জরুরি নয়।',
    '- মানুষ যেভাবে ছোট ছোট বাক্যে কথা বলে সেভাবে বলবে; ইউজারের কথার ধরন ও মেজাজের সঙ্গে তাল মিলিয়ে রিপ্লাই দেবে। উত্তর সংক্ষিপ্ত রাখবে (বেশিরভাগ সময় ১-৩ বাক্য)।',
    '- ব্যবহারকারী বাংলায় লিখলে বাংলায়, ইংরেজিতে লিখলে ইংরেজিতে উত্তর দেবে।',
    '- কেউ আন্তরিকভাবে জানতে চাইলে তুমি বট/AI কি না, তখন মিথ্যা বলবে না — মিষ্টি করে জানাবে যে তুমি একটি বট সহকারী, তারপর স্বাভাবিকভাবে কথা চালিয়ে যাবে।',
    `এখন যার সঙ্গে কথা বলছো তার নাম: ${name}${inGroup ? ' (এটি একটি গ্রুপ চ্যাট)' : ''}।`
  ].join('\n');
}
async function askAI(messages, name, inGroup) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25000);
  try {
    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://render.com',
        'X-Title': 'Mim Jannat Telegram Bot'
      },
      body: JSON.stringify({
        model: OPENROUTER_MODEL,
        messages: [{
          role: 'system',
          content: systemPrompt(name, inGroup)
        }, ...messages],
        temperature: 0.8,
        frequency_penalty: 0.4,
        presence_penalty: 0.3,
        max_tokens: 500
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const detail = data.error?.message || `OpenRouter HTTP ${response.status}`;
      const apiError = new Error(detail);
      apiError.retryable = response.status === 429 || response.status >= 500;
      throw apiError;
    }
    const answer = data.choices?.[0]?.message?.content;
    if (typeof answer !== 'string' || !answer.trim()) throw new Error('OpenRouter returned an empty response');
    return answer.trim();
  } catch (error) {
    if (error.name === 'AbortError') {
      const timeoutError = new Error('AI request timed out after 25 seconds');
      timeoutError.retryable = true;
      throw timeoutError;
    }
    if (error instanceof TypeError) error.retryable = true; // network failure
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}
// One automatic retry for timeouts, network errors, HTTP 429 and 5xx.
async function askAIRetry(messages, name, inGroup) {
  try { return await askAI(messages, name, inGroup); }
  catch (error) {
    if (!error.retryable) throw error;
    console.error('AI request failed, retrying once:', error.message);
    await new Promise(resolve => setTimeout(resolve, 1500));
    return askAI(messages, name, inGroup);
  }
}
async function aiReply(ctx, text, key) {
  const stored = (db.conversations[key] || []).slice();
  const history = stored.slice(-HISTORY_SEND);
  history.push({ role: 'user', content: text.slice(0, 3000) });
  await ctx.api.sendChatAction(ctx.chat.id, 'typing').catch(() => {});
  const answer = await askAIRetry(history, nameOf(ctx), isGroup(ctx));
  stored.push({ role: 'user', content: text.slice(0, 3000) });
  stored.push({ role: 'assistant', content: answer });
  db.conversations[key] = stored.slice(-HISTORY_KEEP);
  db.convTimes = db.convTimes || {};
  db.convTimes[key] = Date.now();
  await saveDb().catch(error => console.error('Conversation save failed:', error.message));
  await ctx.reply(answer, { reply_parameters: { message_id: ctx.msg.message_id } });
}
// Only emojis from Telegram's allowed reaction list work (e.g. ✨ is not allowed).
const REACTIONS = ['❤','👍','🔥','🥰','😍','💯','🤩','👏','🙏','💘','😘','🤗'];
const pickReaction = () => REACTIONS[Math.floor(Math.random() * REACTIONS.length)];
async function maybeReact(ctx) {
  if (isGroup(ctx) && !extra.groupSetting(ctx.chat.id, 'react')) return;
  const emoji = pickReaction();
  await ctx.api.setMessageReaction(ctx.chat.id, ctx.msg.message_id, [{ type: 'emoji', emoji }]).catch(e => console.error('Reaction unavailable:', e.message));
}

function helpKeyboard() {
  return new InlineKeyboard()
    .text('👑 Owner Commands', 'help:owner').row()
    .text('👥 Group Commands', 'help:group').row()
    .text('🌸 Welcome Settings', 'help:welcome').row()
    .text('🔘 Button Message', 'help:button').row()
    .text('🤖 AI & Auto Reply', 'help:ai').row()
    .text('📢 /All Broadcast', 'help:broadcast').row()
    .text('🔒 Force Join', 'help:forcejoin').row()
    .text('⚙️ Group Settings', 'help:settings').row()
    .text('🛡 Master Admin Panel', 'help:admin').row()
    .text('🧰 Group Owner Panel', 'help:panel').row()
    .text('👑 Premium Group Dashboard', 'help:premium').row()
    .text('👑 Bot Creator', 'help:creator').row()
    .text('❌ বন্ধ করুন', 'help:close');
}
const HELP = {
  home: '📚 MIM JANNAT BOT — সম্পূর্ণ ব্যবহার নির্দেশিকা\n👑 Bot Creator: GTS Tarek\nনিচের বাটনে চাপ দিয়ে যে ফিচারটি জানতে চাও সেটি বেছে নাও। প্রতিটি বিভাগে কোথায় কমান্ড দিতে হবে এবং ধাপে ধাপে কী করতে হবে লেখা আছে।',
  owner: '👑 OWNER COMMANDS\n\n/start — Private Chat-এ বট চালু করে। শুধু নির্দিষ্ট Owner ID-র অ্যাকাউন্টে Owner সুবিধা চালু হবে।\n/help — এই নির্দেশিকা খুলবে।\n/id — নিজের Telegram ID ও বর্তমান Chat ID দেখাবে।\n/send — শুধু Owner-এর Private Chat-এ। প্রথমে মেসেজ/ছবি/ভিডিও/ভয়েস/ডকুমেন্ট পাঠাও, তারপর গ্রুপের @username বা numeric Chat ID দাও, Preview দেখে Send/Cancel চাপো।\n/baton — Button-সহ মেসেজ তৈরি করবে। ধাপে ধাপে মেসেজ, বাটনের নাম, URL, গন্তব্য ও Sender label চাইবে।',
  group: '👥 GROUP COMMANDS\n\nএই কমান্ডগুলো গ্রুপে ব্যবহার করবে। বটের Owner অথবা ওই গ্রুপের Creator ব্যবহার করতে পারবেন।\n/set — Trigger শব্দ পাঠাও, এরপর বটের নির্দিষ্ট Reply পাঠাও।\n/list — ওই গ্রুপের সব Custom Reply দেখাবে।\n/del 1 — /list-এর ১ নম্বর Reply মুছবে।\n/cancel — চলমান /set বা /send বা /baton কাজ বাতিল করবে।\n/id — গ্রুপের numeric Chat ID দেখাবে।\nনোট: বটের Owner সব গ্রুপে Custom Reply পরিচালনা করতে পারবে; অন্য সদস্যদের জন্য Telegram Group Creator Status যাচাই হবে।',
  welcome: '🌸 WELCOME SETTINGS\n\n/welcome কমান্ডটি Owner-এর Private Chat-এ দাও।\n১) Edit চাপলে নতুন Welcome Message লিখবে।\n২) বট Preview দেখাবে।\n৩) Confirm করলে নতুন মেসেজ সংরক্ষিত হবে।\n৪) ON/OFF দিয়ে নতুন সদস্যদের Welcome চালু/বন্ধ করবে।\nএটি সব গ্রুপে একই Welcome Text ব্যবহার করবে। নতুন সদস্য যোগ হলে বট গ্রুপে সেটি পাঠাবে।',
  button: '🔘 BUTTON MESSAGE — /baton\n\n১) Owner-এর Private Chat-এ /baton লিখবে।\n২) যে মেসেজটি পাঠাতে চাও সেটি পাঠাবে (text/photo/video/document ইত্যাদি)।\n৩) বাটনের নাম লিখবে।\n৪) বাটনে ক্লিক করলে যে HTTPS/Telegram URL খুলবে সেটি পাঠাবে।\n৫) প্রতিটি বাটনের রঙ বেছে নেবে: 🔵 নীল, 🟢 সবুজ, 🔴 লাল বা ⚪ ডিফল্ট। (রঙ শুধু নতুন Telegram অ্যাপে দেখা যায়।)\n৬) Destination গ্রুপের @username বা numeric Chat ID দেবে। Private invite link থেকে Chat ID বের করা যায় না।\n৭) Sender label বেছে নেবে: Owner-এর পক্ষ থেকে অথবা Bot-এর পক্ষ থেকে।\n৮) Preview-তে মেসেজ, লিংক বাটন, Send ও Cancel দেখবে। Send চাপলে বটের অ্যাকাউন্ট থেকে গ্রুপে যাবে। Bot API দিয়ে ব্যক্তিগত Telegram account-এর হয়ে পাঠানো সম্ভব নয়।',
  broadcast: '📢 /All — GLOBAL BROADCAST (শুধু Bot Creator)\n\nOwner-এর Private Chat-এ /All লিখলে:\n১) যে মেসেজ পাঠাতে চাও সেটি পাঠাও (Text/Photo/Video/Voice/Document)।\n২) Button যোগ করবে কি না — Yes/No।\n৩) Yes হলে Button-এর নাম, URL ও রঙ দাও।\n৪) Preview দেখে ✅ Send All বা ❌ Cancel চাপো।\nমেসেজ যাবে বটকে /start করা সব User এবং বট যেসব গ্রুপে আছে সেসব গ্রুপে। শেষে Report: Total, Sent, Failed, Blocked/Unreachable। চলার সময় ⛔ Cancel Broadcast চাপা যাবে।',
  forcejoin: '🔒 FORCE JOIN\n\nসাধারণ ব্যবহারকারী ও Group Creator-কে বটের ফিচার ব্যবহারের আগে নির্ধারিত সব Channel-এ Join করে ✅ Verify চাপতে হয়। Channel ছেড়ে দিলে ফিচার আবার Lock হয়। Bot Creator-এর জন্য প্রযোজ্য নয়।\n\nOwner কমান্ড (Private Chat): /channels — Channel যোগ/মুছা, Force Join ON/OFF। বটকে আগে ওই Channel-এ Admin করতে হবে।',
  settings: '⚙️ GROUP SETTINGS\n\nগ্রুপে /settings লিখলে (শুধু ওই গ্রুপের Creator বা Owner) AI Reply, Auto Reply, Reactions ও Welcome চালু/বন্ধ করা যায়। প্রতিটি গ্রুপের সেটিংস আলাদা।\nPrivate Chat-এ /settings বা /panel দিলে নিজের (Telegram-এ যাচাই করা) গ্রুপের তালিকা আসে; গ্রুপ বেছে সব সেটিংস ও Custom Reply সেখান থেকেই বদলানো যায়।\n/welcome — গ্রুপে লিখলে ওই গ্রুপের নিজস্ব Welcome Message Edit/Preview/ON-OFF। Private Chat-এ /welcome দিয়ে নিজের গ্রুপ বেছেও করা যায়।\n/send ও /baton — Private Chat-এ ব্যবহার করে নিজের গ্রুপে মেসেজ পাঠানো যায়।',
  admin: '🛡 MASTER ADMIN PANEL — /admin (শুধু Bot Creator)\n\nBot Creator-এর Private Chat-এ /admin লিখলে আলাদা প্যানেল খোলে। অন্য কেউ ঢুকতে পারে না।\n📊 Dashboard — মোট ইউজার, মোট গ্রুপ, বর্তমানে বট যুক্ত গ্রুপ, সক্রিয় গ্রুপ।\n👥 User Management — সব ইউজারের তালিকা, তথ্য, Ban/Unban, AI মেমোরি মুছা।\n🏠 Group Management — সব গ্রুপের নাম, ID, Creator, সেটিংস; যেকোনো গ্রুপের সেটিংস/Welcome/Custom Reply পরিবর্তন।\n🚫 Ban / Unban — Ban করা ইউজার বটের কোনো ফিচার ব্যবহার করতে পারে না।\n⚙️ Global Settings — সব গ্রুপ ও ইউজারের জন্য AI, Auto Reply, Reaction, Welcome ও Maintenance Mode।\n📢 Broadcast — /All-এর মতোই। 📈 Statistics — বিস্তারিত পরিসংখ্যান।\n/settings (Private Chat) — সব গ্রুপের তালিকা থেকে একটি বেছে সেটিংস পরিবর্তন।',
  panel: '🧰 GROUP OWNER PANEL — /panel\n\nযেকোনো গ্রুপ Creator বটের Private Chat-এ /panel বা /settings লিখবে। Telegram API দিয়ে প্রকৃত Creator যাচাই হয়; শুধু তার নিজের গ্রুপগুলো দেখায়।\n১) গ্রুপ বেছে নাও।\n২) সেখানে AI Reply, Auto Reply, Reactions, Welcome (Edit/Preview/ON-OFF), Custom Replies (যোগ/মুছা) এবং Group Info পাবে।\nপ্রতিটি গ্রুপের সেটিংস আলাদা। অন্য গ্রুপ, Global Ban, /All, Token/API Key/Database/Hosting — এগুলোতে Creator-এর অধিকার নেই।\nবটকে গ্রুপে Admin রাখলে যাচাই সবচেয়ে নির্ভরযোগ্য।',
  ai: '🤖 AI & AUTO REPLY\n\nPrivate Chat-এ সাধারণ মেসেজ লিখলে AI উত্তর দেবে।\nGroup-এ শুধু বটকে @mention করলে অথবা বটের মেসেজে Reply করলে AI উত্তর দেবে।\nHi, Hello, সালাম, কেমন আছো, Good Morning ইত্যাদি নির্দিষ্ট Trigger-এ Fixed Reply দেবে।\n/set দিয়ে নিজের Trigger/Reply তৈরি করা যায়। AI চালাতে OpenRouter API Key এবং মডেল ব্যবহারের অনুমতি/ক্রেডিট লাগতে পারে।'
};

bot.command('start', async ctx => {
  if (!isPrivate(ctx)) return ctx.reply('আমাকে ব্যক্তিগত চ্যাটে /start দাও।');
  if (isOwner(ctx)) return ctx.reply('আসসালামু আলাইকুম, Owner! 🌸\nMIM JANNAT BOT চালু আছে। 👑 Bot Creator: GTS Tarek\n/help দিয়ে নির্দেশিকা দেখো।');
  return ctx.reply('আসসালামু আলাইকুম! 🌸\nআমি MIM JANNAT BOT। আমার Official Creator হলেন GTS Tarek। কীভাবে সাহায্য করতে পারি?');
});
bot.command('help', ctx => ctx.reply(HELP.home, { reply_markup: helpKeyboard() }));
bot.callbackQuery(/^help:(.+)$/, async ctx => {
  const section = ctx.match[1];
  if (section === 'close') { await ctx.deleteMessage().catch(() => {}); return ctx.answerCallbackQuery(); }
  await ctx.answerCallbackQuery();
  if (section === 'home') return ctx.editMessageText(HELP.home, { reply_markup: helpKeyboard() });
  if (section === 'creator') return ctx.editMessageText(`👑 Bot Creator Information\n\nOfficial Creator: GTS Tarek\nBot Name: MIM JANNAT BOT\nVersion: ${BOT_VERSION}\nCreator Status: Official Bot Creator\n\nCreator permission is verified using the configured numeric Telegram ID.`, { reply_markup:new InlineKeyboard().text('⬅️ মূল Help','help:home') });
  if (section === 'premium') return premium.openSelection(ctx);
  await ctx.editMessageText(HELP[section] || HELP.home, { reply_markup: new InlineKeyboard().text('⬅️ মূল Help', 'help:home').text('❌ বন্ধ', 'help:close') }).catch(async () => ctx.reply(HELP[section] || HELP.home));
});
bot.command('id', async ctx => {
  let text = `এই চ্যাটের ID: ${ctx.chat.id}\nতোমার Telegram ID: ${ctx.from.id}`;
  if (isOwner(ctx)) text += '\nপরিচয়: 👑 বটের Owner';
  if (isGroup(ctx)) {
    const r = await groupCreatorCheck(ctx);
    if (r.allowed) text += '\nএই গ্রুপে: 👑 গ্রুপ Creator';
    else if (r.error || r.unverified) text += '\nএই গ্রুপে: Unverified (Telegram Creator পরিচয় যাচাই করতে পারেনি)';
    else text += '\nএই গ্রুপে: সাধারণ সদস্য/Admin (Creator নন)';
  }
  return ctx.reply(text);
});
bot.command('cancel', async ctx => { pending.delete(keyOf(ctx)); await ctx.reply('চলমান কাজ বাতিল করা হয়েছে।'); });

bot.command('set', async ctx => {
  if (!isGroup(ctx)) return ctx.reply('এই কমান্ডটি গ্রুপে ব্যবহার করো।');
  const permission = await canManageGroup(ctx);
  if (!permission.allowed) return permissionFailure(ctx, permission);
  pending.set(keyOf(ctx), { type: 'set', step: 'trigger' });
  return ctx.reply('কোন শব্দ/মেসেজের জন্য Reply সেট করতে চাও? Trigger পাঠাও।\nবাতিল: /cancel');
});
bot.command('list', async ctx => {
  if (!isGroup(ctx)) return ctx.reply('এই কমান্ডটি গ্রুপে ব্যবহার করো।');
  const permission = await canManageGroup(ctx);
  if (!permission.allowed) return permissionFailure(ctx, permission);
  const items = db.customReplies[String(ctx.chat.id)] || [];
  return ctx.reply(items.length ? 'Custom Replies:\n' + items.map((x,i)=>`${i+1}. ${x.trigger} → ${x.reply}`).join('\n') : 'এখনো কোনো Custom Reply নেই। /set দিয়ে তৈরি করো।');
});
bot.command('del', async ctx => {
  if (!isGroup(ctx)) return ctx.reply('এই কমান্ডটি গ্রুপে ব্যবহার করো।');
  const permission = await canManageGroup(ctx);
  if (!permission.allowed) return permissionFailure(ctx, permission);
  const list = db.customReplies[String(ctx.chat.id)] || [];
  const n = Number((ctx.match || '').trim());
  if (!Number.isInteger(n) || n < 1 || n > list.length) return ctx.reply('মুছতে /del 1 এভাবে নম্বর দাও। আগে /list দেখো।');
  const [removed] = list.splice(n-1,1); db.customReplies[String(ctx.chat.id)] = list; await saveDb();
  return ctx.reply(`মুছে ফেলা হয়েছে: ${removed.trigger}`);
});

bot.command('welcome', async ctx => {
  // Owner in private chat: the original global default welcome. Group Creators: per-group welcome (v1.8).
  if (!(isPrivate(ctx) && isOwner(ctx))) return extra.welcomeCommand(ctx);
  const kb = new InlineKeyboard().text('✏️ Edit Welcome', 'welcome:edit').row().text(db.welcome.enabled ? '🔴 OFF' : '🟢 ON', 'welcome:toggle').text('👁 Preview', 'welcome:preview');
  return ctx.reply(`🌸 Welcome Message Settings\nStatus: ${db.welcome.enabled ? 'ON' : 'OFF'}\n\nবর্তমান মেসেজ:\n\n${db.welcome.text}`, { reply_markup: kb });
});
bot.callbackQuery(/^welcome:(edit|toggle|preview)$/, async ctx => {
  if (!isOwner(ctx)) return ctx.answerCallbackQuery({ text: 'শুধু Owner ব্যবহার করতে পারবেন।', show_alert: true });
  const action = ctx.match[1];
  if (action === 'edit') { pending.set(keyOf(ctx), { type: 'welcome', step: 'text' }); await ctx.answerCallbackQuery(); return ctx.reply('নতুন Welcome Message লিখে পাঠাও। এরপর Preview ও Confirm দেখানো হবে। বাতিল: /cancel'); }
  if (action === 'toggle') { db.welcome.enabled = !db.welcome.enabled; await saveDb(); await ctx.answerCallbackQuery({ text: db.welcome.enabled ? 'Welcome ON' : 'Welcome OFF' }); return ctx.editMessageText(`🌸 Welcome Message Settings\nStatus: ${db.welcome.enabled ? 'ON' : 'OFF'}\n\n${db.welcome.text}`, { reply_markup: new InlineKeyboard().text('✏️ Edit Welcome','welcome:edit').row().text(db.welcome.enabled ? '🔴 OFF' : '🟢 ON','welcome:toggle').text('👁 Preview','welcome:preview') }); }
  await ctx.answerCallbackQuery(); return ctx.reply(db.welcome.text);
});
bot.callbackQuery(/^welcomeconfirm:(.+)$/, async ctx => {
  if (!isOwner(ctx)) return ctx.answerCallbackQuery({ text: 'শুধু Owner পারবেন।', show_alert: true });
  const id = ctx.match[1], draft = jobs.get(id);
  if (!draft) return ctx.answerCallbackQuery({ text: 'Preview-এর মেয়াদ শেষ। আবার /welcome দাও।', show_alert: true });
  db.welcome.text = draft.text; db.welcome.enabled = true; jobs.delete(id); await saveDb();
  await ctx.answerCallbackQuery({ text: 'Welcome Message সংরক্ষিত হয়েছে।' });
  await ctx.editMessageText('✅ নতুন Welcome Message সংরক্ষিত হয়েছে এবং ON করা হয়েছে।');
});
bot.callbackQuery(/^welcomecancel:(.+)$/, async ctx => { if (!isOwner(ctx)) return ctx.answerCallbackQuery({ text: 'শুধু Owner পারবেন।', show_alert: true }); jobs.delete(ctx.match[1]); await ctx.answerCallbackQuery({ text: 'বাতিল করা হয়েছে।' }); await ctx.editMessageText('❌ Welcome Message পরিবর্তন বাতিল।'); });

bot.command('send', async ctx => {
  if (!isPrivate(ctx)) return ctx.reply('এই কমান্ডটি শুধু Private Chat-এ ব্যবহার করা যাবে।');
  pending.set(keyOf(ctx), { type: 'send', step: 'content', userId: ctx.from.id });
  return ctx.reply('যে Text/Photo/Video/Voice/Document গ্রুপে পাঠাতে চাও সেটি পাঠাও।\nবাতিল: /cancel');
});
bot.command('baton', async ctx => {
  if (!isPrivate(ctx)) return ctx.reply('/baton শুধু Private Chat-এ ব্যবহার করা যাবে।');
  pending.set(keyOf(ctx), { type: 'button', step: 'content', userId: ctx.from.id });
  return ctx.reply('প্রথমে যে মেসেজের নিচে Button দিতে চাও সেটি পাঠাও। Text, Photo, Video বা Document দিতে পারো।\nবাতিল: /cancel');
});

bot.on('my_chat_member', async ctx => {
  const s = ctx.myChatMember.new_chat_member.status;
  if (['member','administrator'].includes(s)) await ctx.api.sendMessage(ctx.chat.id, 'আসসালামু আলাইকুম! 🌸\nআমি Mim Jannat। /help দিয়ে আমার কমান্ডগুলো জানতে পারো।').catch(e => console.error('Bot join welcome:', e.message));
});
bot.on('message:new_chat_members', async ctx => {
  const names = ctx.message.new_chat_members.filter(x => !x.is_bot).map(x => x.first_name).filter(Boolean);
  if (!names.length) return;
  const pc = premium.cfgFor(ctx.chat.id);
  if (pc.welcome.enabled && extra.globalEnabled('welcome')) {
    const caption = String(pc.welcome.caption || pc.welcome.text).replaceAll('{name}', names.join(', '));
    const opts = { reply_parameters: { message_id: ctx.msg.message_id } };
    if (pc.welcome.buttons?.length) { const kb = new InlineKeyboard(); for (const b of pc.welcome.buttons) kb.url(b.label,b.url).row(); opts.reply_markup = kb; }
    try {
      let sent;
      if (pc.welcome.mediaType === 'photo' && pc.welcome.fileId) sent = await ctx.replyWithPhoto(pc.welcome.fileId,{...opts,caption});
      else if (pc.welcome.mediaType === 'video' && pc.welcome.fileId) sent = await ctx.replyWithVideo(pc.welcome.fileId,{...opts,caption});
      else sent = await ctx.reply(caption,opts);
      if (pc.welcome.deleteAfter > 0) setTimeout(() => ctx.api.deleteMessage(ctx.chat.id,sent.message_id).catch(()=>{}), Math.min(pc.welcome.deleteAfter,86400)*1000).unref?.();
    } catch(e) { console.error('Premium welcome failed:',e.message); }
    return;
  }
  const welcomeCfg = extra.effectiveWelcome(ctx.chat.id);
  if (!welcomeCfg.enabled) return;
  const text = welcomeCfg.text.replaceAll('{name}', names.join(', '));
  await ctx.reply(text, { reply_parameters: { message_id: ctx.msg.message_id } }).catch(e => console.error('Member welcome failed:', e.message));
});

extra.installFlows();
panels.installFlows();
bot.on('message', async ctx => {
  const msg = ctx.msg;
  const text = msg.text || msg.caption || '';
  const k = keyOf(ctx);
  const flow = pending.get(k);

  if (flow && !isCommand(text)) {
    if (flow.type === 'set' && isGroup(ctx)) {
      if (flow.step === 'trigger') { flow.trigger = text.trim(); flow.step = 'reply'; pending.set(k, flow); return ctx.reply('এই Trigger-এর জন্য বট কী উত্তর দেবে? Reply পাঠাও।'); }
      if (flow.step === 'reply') { const list = db.customReplies[String(ctx.chat.id)] || []; const i = list.findIndex(x => norm(x.trigger) === norm(flow.trigger)); const item = { trigger: flow.trigger, reply: text.trim() }; if (i >= 0) list[i] = item; else list.push(item); db.customReplies[String(ctx.chat.id)] = list; pending.delete(k); await saveDb(); return ctx.reply(`সেট হয়েছে!\nTrigger: ${item.trigger}\nReply: ${item.reply}`); }
    }
    if (flow.type === 'welcome' && isPrivate(ctx) && isOwner(ctx)) {
      const id = `welcome_${Date.now()}_${ctx.from.id}`; jobs.set(id, { text: text.trim() }); pending.delete(k);
      const kb = new InlineKeyboard().text('✅ Confirm & Save', `welcomeconfirm:${id}`).text('❌ Cancel', `welcomecancel:${id}`);
      return ctx.reply(`🌸 Welcome Message Preview\n\n${text.trim()}\n\nএটাই কি নতুন Welcome Message হবে?`, { reply_markup: kb });
    }
    if ((flow.type === 'send' || flow.type === 'button') && isPrivate(ctx)) {
      if (flow.step === 'content') { flow.fromChatId = ctx.chat.id; flow.messageId = msg.message_id; flow.step = flow.type === 'send' ? 'destination' : 'label'; pending.set(k, flow); return ctx.reply(flow.type === 'send' ? 'এখন destination গ্রুপের @username অথবা numeric Chat ID পাঠাও।' : 'Button-এর নাম কী হবে? নাম লিখে পাঠাও।'); }
      if (flow.type === 'button' && flow.step === 'label') { flow.label = text.trim(); flow.step = 'url'; pending.set(k, flow); return ctx.reply('এখন Button-এ ক্লিক করলে যে URL খুলবে সেটি পাঠাও (https:// অথবা t.me/ লিংক)।'); }
      if (flow.type === 'button' && flow.step === 'url') { if (!/^https?:\/\//i.test(text.trim()) && !/^t\.me\//i.test(text.trim())) return ctx.reply('সঠিক URL দাও। https:// অথবা t.me/ দিয়ে শুরু করো।'); flow.url = /^t\.me\//i.test(text.trim()) ? `https://${text.trim()}` : text.trim(); flow.step = 'color'; pending.set(k, flow); return ctx.reply(`এই বাটনের রঙ কী হবে? (বাটন: ${flow.label})`, { reply_markup: new InlineKeyboard().text('🔵 নীল', 'btncolor:primary').text('🟢 সবুজ', 'btncolor:success').row().text('🔴 লাল', 'btncolor:danger').text('⚪ ডিফল্ট', 'btncolor:default') }); }
      if (flow.step === 'destination') {
        let dest = text.trim(); const m = dest.match(/(?:https?:\/\/)?t\.me\/([A-Za-z0-9_]{5,})\/?$/i); if (m) dest = '@' + m[1];
        if (!/^@?[A-Za-z0-9_]{5,}$/.test(dest) && !/^-?\d+$/.test(dest)) return ctx.reply('Destination হিসেবে @username অথবা numeric Chat ID দাও।');
        // Group Creators may only send to a group they created (server-side Telegram creator check). Owner: unrestricted.
        if (!isOwner(ctx)) { const target = await extra.resolveDestination(ctx.api, dest, ctx.from.id); if (!target.ok) return ctx.reply(target.message); dest = String(target.chat.id); }
        flow.destination = dest;
        if (flow.type === 'button') { flow.step = 'sender'; pending.set(k, flow); const kb = new InlineKeyboard().text('👤 Owner-এর পক্ষ থেকে', 'sender:owner').row().text('🤖 Bot-এর পক্ষ থেকে', 'sender:bot'); return ctx.reply('মেসেজে কোন পরিচয় দেখাতে চাও?', { reply_markup: kb }); }
        const id = `send_${Date.now()}_${ctx.from.id}`; jobs.set(id, flow); pending.delete(k);
        const kb = new InlineKeyboard().text('✅ Send', `jobsend:${id}`).text('❌ Cancel', `jobcancel:${id}`);
        const preview = await ctx.api.copyMessage(ctx.chat.id, flow.fromChatId, flow.messageId, { reply_markup: kb }).catch(e => { console.error('Preview copy failed:', e.message); return null; });
        if (!preview) return ctx.reply('Preview তৈরি করা যায়নি। অন্য মেসেজ দিয়ে আবার চেষ্টা করো।');
        return ctx.reply(`উপরের মেসেজটি পাঠানো হবে।\nDestination: ${dest}\nSend অথবা Cancel চাপো।`);
      }
    }
  }

  if (isPrivate(ctx) && !isCommand(text) && text) {
    if (!isOwner(ctx) && !extra.globalEnabled('ai')) return ctx.reply('এখন AI reply সাময়িকভাবে বন্ধ আছে। পরে আবার চেষ্টা করো। 🌸');
    try { return await aiReply(ctx, text, `private:${ctx.from.id}`); }
    catch (e) { console.error('Private AI error:', e.message); return ctx.reply('AI সেবায় সমস্যা হচ্ছে। একটু পরে আবার চেষ্টা করো।'); }
  }
  if (isGroup(ctx)) {
    if (isCommand(text)) return;
    const entities = msg.entities || msg.caption_entities || [];
    const botUser = botInfo ? botInfo.username.toLowerCase() : '';
    const mentioned = Boolean(botInfo) && entities.some(e =>
      (e.type === 'mention' && text.slice(e.offset, e.offset + e.length).toLowerCase() === `@${botUser}`) ||
      (e.type === 'text_mention' && e.user?.id === botInfo.id)
    ) || (Boolean(botInfo) && new RegExp(`(^|[^A-Za-z0-9_])@${botUser}(?![A-Za-z0-9_])`, 'i').test(text));
    const replied = msg.reply_to_message?.from?.id === botInfo?.id;
    if ((mentioned || replied) && text) {
      const cleaned = botInfo ? text.replace(new RegExp(`@${botInfo.username}`, 'ig'), ' ').replace(/\s+/g, ' ').trim() : text.trim();
      const replyOpts = { reply_parameters: { message_id: msg.message_id } };
      // Only a mention (no other words): greet without needing the AI service.
      if (!cleaned) {
        const greetings = ['জি, বলো! 😊', 'হ্যাঁ, আমি আছি! 🌸 কী খবর?', 'হ্যালো! 😊 কেমন আছো?', 'জি, শুনছি! বলো কী লাগবে? 💚'];
        const greet = greetings[Math.floor(Math.random() * greetings.length)];
        await ctx.reply(greet, replyOpts);
        rememberTurn(convKeyOf(ctx), '(শুধু মেনশন করেছে)', greet);
        await maybeReact(ctx);
        return;
      }
      const gKey = convKeyOf(ctx);
      const fixedMention = extra.groupSetting(ctx.chat.id, 'auto') ? fixedReply(ctx.chat.id, cleaned, gKey) : null;
      if (fixedMention) { await ctx.reply(fixedMention, replyOpts); rememberTurn(gKey, cleaned, fixedMention); await maybeReact(ctx); return; }
      if (!extra.groupSetting(ctx.chat.id, 'ai')) { await maybeReact(ctx); return; }
      try { await aiReply(ctx, cleaned, `group:${ctx.chat.id}:${ctx.from.id}`); }
      catch (e) { console.error('Group AI error:', e.message); await ctx.reply('AI সেবায় এখন সমস্যা হচ্ছে। একটু পরে আবার বলো। 🌸', replyOpts).catch(() => {}); }
      await maybeReact(ctx);
      return;
    }
    const gKey2 = convKeyOf(ctx);
    const fixed = extra.groupSetting(ctx.chat.id, 'auto') ? fixedReply(ctx.chat.id, text, gKey2) : null;
    if (fixed) { await ctx.reply(fixed, { reply_parameters: { message_id: msg.message_id } }); rememberTurn(gKey2, text, fixed); await maybeReact(ctx); return; }
    await maybeReact(ctx);
  }
});

// Telegram supports 3 button colors: primary (blue), success (green), danger (red). No style = default.
const BTN_COLOR_NAME = { primary: '🔵 নীল', success: '🟢 সবুজ', danger: '🔴 লাল' };
function buildUrlKb(buttons, withStyle = true) {
  const kb = new InlineKeyboard();
  for (const b of buttons) {
    kb.url(b.label, b.url);
    if (withStyle && b.style) { const row = kb.inline_keyboard[kb.inline_keyboard.length - 1]; row[row.length - 1].style = b.style; }
    kb.row();
  }
  return kb;
}
bot.callbackQuery(/^btncolor:(primary|success|danger|default)$/, async ctx => {
  if (!isPrivate(ctx)) return ctx.answerCallbackQuery({ text: 'এই কাজ শুধু Private Chat-এ করা যাবে।', show_alert: true });
  const flow = pending.get(keyOf(ctx)); if (!flow || flow.type !== 'button' || flow.step !== 'color') return ctx.answerCallbackQuery({ text: 'এই ধাপের মেয়াদ শেষ। /baton দিয়ে আবার শুরু করো।', show_alert: true });
  await ctx.answerCallbackQuery();
  await ctx.editMessageReplyMarkup({ reply_markup: new InlineKeyboard() }).catch(() => {});
  const style = ctx.match[1] === 'default' ? undefined : ctx.match[1];
  flow.buttons = flow.buttons || [];
  flow.buttons.push({ label: flow.label, url: flow.url, style });
  flow.step = 'more'; pending.set(keyOf(ctx), flow);
  return ctx.reply(`✅ বাটন যোগ হয়েছে (মোট ${flow.buttons.length}টি, রঙ: ${style ? BTN_COLOR_NAME[style] : '⚪ ডিফল্ট'})।\n\nআরেকটি বাটন যোগ করতে চাও?`, { reply_markup: new InlineKeyboard().text('➕ হ্যাঁ, আরেকটি', 'morebtn:yes').text('➡️ না, পরের ধাপে', 'morebtn:no') });
});
bot.callbackQuery(/^morebtn:(yes|no)$/, async ctx => {
  if (!isPrivate(ctx)) return ctx.answerCallbackQuery({ text: 'এই কাজ শুধু Private Chat-এ করা যাবে।', show_alert: true });
  const flow = pending.get(keyOf(ctx)); if (!flow || flow.type !== 'button' || flow.step !== 'more') return ctx.answerCallbackQuery({ text: 'এই ধাপের মেয়াদ শেষ। /baton দিয়ে আবার শুরু করো।', show_alert: true });
  await ctx.answerCallbackQuery();
  await ctx.editMessageReplyMarkup({ reply_markup: new InlineKeyboard() }).catch(() => {});
  if (ctx.match[1] === 'yes') { flow.step = 'label'; pending.set(keyOf(ctx), flow); return ctx.reply('পরের Button-এর নাম কী হবে? নাম লিখে পাঠাও।'); }
  flow.step = 'destination'; pending.set(keyOf(ctx), flow);
  return ctx.reply('এখন যে গ্রুপে পাঠাতে চাও তার @username অথবা numeric Chat ID পাঠাও। Private invite link নয়।');
});
bot.callbackQuery(/^sender:(owner|bot)$/, async ctx => {
  if (!isPrivate(ctx)) return ctx.answerCallbackQuery({ text: 'এই কাজ শুধু Private Chat-এ করা যাবে।', show_alert: true });
  const flow = pending.get(keyOf(ctx)); if (!flow || flow.type !== 'button' || flow.step !== 'sender') return ctx.answerCallbackQuery({ text: 'এই ধাপের মেয়াদ শেষ। /baton দিয়ে আবার শুরু করো।', show_alert: true });
  flow.sender = ctx.match[1]; flow.step = 'confirm'; pending.set(keyOf(ctx), flow);
  const id = `button_${Date.now()}_${ctx.from.id}`; jobs.set(id, flow); flow.jobId = id;
  const label = flow.sender === 'owner' ? '👤 Owner-এর পক্ষ থেকে' : '🤖 Mim Jannat Bot-এর পক্ষ থেকে';
  const kb = buildUrlKb(flow.buttons || [{ label: flow.label, url: flow.url }]).text('✅ Send', `jobsend:${id}`).text('❌ Cancel', `jobcancel:${id}`);
  await ctx.answerCallbackQuery();
  await ctx.reply(`🔎 Button Message Preview\nপরিচয়: ${label}\nDestination: ${flow.destination}\nনিচের Preview-তে Button ও Send/Cancel আছে।`);
  const copied = await ctx.api.copyMessage(ctx.chat.id, flow.fromChatId, flow.messageId, { reply_markup: kb }).catch(e => { console.error('Button preview failed:', e.message); return null; });
  if (!copied) { jobs.delete(id); pending.delete(keyOf(ctx)); return ctx.reply('Button Preview তৈরি করা যায়নি। /baton দিয়ে আবার চেষ্টা করো।'); }
  pending.delete(keyOf(ctx));
});
bot.callbackQuery(/^jobsend:(.+)$/, async ctx => {
  const id = ctx.match[1], job = jobs.get(id); if (!job) return ctx.answerCallbackQuery({ text: 'এই Preview আর বৈধ নয়। আবার শুরু করো।', show_alert: true });
  if (String(job.userId || OWNER_TELEGRAM_ID) !== String(ctx.from.id)) return ctx.answerCallbackQuery({ text: 'এই Preview তোমার নয়।', show_alert: true });
  // Re-check on the server at send time: only the Owner or the real creator of the destination group may send.
  if (!isOwner(ctx) && !(await extra.canSendTo(ctx.api, job.destination, ctx.from.id))) return ctx.answerCallbackQuery({ text: 'শুধু নিজের তৈরি গ্রুপে পাঠানো যাবে।', show_alert: true });
  try {
    if (job.type === 'button') {
      const btns = job.buttons || [{ label: job.label, url: job.url }];
      try {
        await ctx.api.copyMessage(job.destination, job.fromChatId, job.messageId, { reply_markup: buildUrlKb(btns) });
      } catch (styleErr) {
        if (!btns.some(b => b.style)) throw styleErr;
        console.error('Send with button colors failed, retrying without colors:', styleErr.message);
        await ctx.api.copyMessage(job.destination, job.fromChatId, job.messageId, { reply_markup: buildUrlKb(btns, false) });
      }
    } else {
      await ctx.api.copyMessage(job.destination, job.fromChatId, job.messageId);
    }
    jobs.delete(id); await ctx.answerCallbackQuery({ text: 'মেসেজ পাঠানো হয়েছে।' });
    await ctx.editMessageText('✅ Destination-এ মেসেজ পাঠানো হয়েছে।').catch(() => {});
  } catch (e) { console.error('Send job failed:', e.message); await ctx.answerCallbackQuery({ text: 'পাঠানো যায়নি। বট গ্রুপে আছে এবং Send permission আছে কি না দেখো।', show_alert: true }); }
});
bot.callbackQuery(/^jobcancel:(.+)$/, async ctx => { const cancelJob = jobs.get(ctx.match[1]); if (String((cancelJob && cancelJob.userId) || OWNER_TELEGRAM_ID) !== String(ctx.from.id)) return ctx.answerCallbackQuery({ text: 'এই Preview তোমার নয়।', show_alert: true }); jobs.delete(ctx.match[1]); await ctx.answerCallbackQuery({ text: 'বাতিল করা হয়েছে।' }); await ctx.editMessageText('❌ পাঠানো বাতিল হয়েছে।').catch(() => {}); });

bot.on('channel_post', async ctx => { if (!extra.globalEnabled('react')) return; await ctx.api.setMessageReaction(ctx.chat.id, ctx.channelPost.message_id, [{ type: 'emoji', emoji: pickReaction() }]).catch(err => console.error('Channel reaction:', err.message)); });

const app = express();
app.get('/', (_req,res) => res.status(200).send('Mim Jannat bot is running.'));
app.get('/health', (_req,res) => res.status(200).json({ ok: true, bot: BOT_NAME, version: BOT_VERSION, creator: BRAND_NAME, storage: DB_FILE }));
const server = app.listen(PORT, '0.0.0.0', () => console.log(`Health server listening on ${PORT}; data file: ${DB_FILE}`));
bot.catch(error => {
  const e = error.error || error;
  if (e && e.error_code) console.error(`Telegram API error ${e.error_code} while handling update ${error.ctx?.update?.update_id}:`, e.description || e.message);
  else console.error('Unhandled Telegram update error:', e);
});

let runnerHandle = null;
let shuttingDown = false;

async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  extra.onShutdown();
  premium.onShutdown();
  console.log(`Received ${signal}; shutting down gracefully...`);
  try {
    if (runnerHandle) await runnerHandle.stop();
    await saveDb().catch(error => console.error('Final database save failed:', error.message));
  } catch (error) {
    console.error('Shutdown error:', error);
  } finally {
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 8000).unref();
  }
}

let pollingConflicts = 0;
function startPolling() {
  // Never start a second polling loop inside this process.
  if (runnerHandle || shuttingDown) return;
  runnerHandle = run(bot, {
    runner: { fetch: { allowed_updates: ['message', 'edited_message', 'callback_query', 'my_chat_member', 'channel_post'] } },
    sink: { concurrency: 8 }
  });
  console.log('Mim Jannat concurrent long-polling runner started (max 8 updates).');
  const task = runnerHandle.task();
  if (!task) return;
  task.then(() => { runnerHandle = null; }).catch(async error => {
    runnerHandle = null;
    if (shuttingDown) return;
    const isConflict = error && (error.error_code === 409 || /Conflict/i.test(String(error.description || error.message)));
    if (isConflict) {
      pollingConflicts++;
      console.error(`409 Conflict: another process is polling with the same BOT_TOKEN (or a webhook is set). Stop the other instance. Attempt ${pollingConflicts}/10 — retrying in 20s without restarting the process.`);
      if (pollingConflicts <= 10) { await new Promise(resolve => setTimeout(resolve, 20000)); return startPolling(); }
      console.error('409 Conflict did not clear after 10 attempts; exiting.');
      return process.exit(1);
    }
    console.error('Polling runner stopped unexpectedly:', error);
    process.exit(1);
  });
}

(async () => {
  try {
    botInfo = await bot.api.getMe();
    // Remove a previously configured webhook before starting long polling.
    await bot.api.deleteWebhook({ drop_pending_updates: false });
    await backupDbBeforeUpgrade();
    await saveDb().catch(error => console.error('Initial database save failed:', error.message));
    console.log(`Starting Mim Jannat as @${botInfo.username}; fixed owner ID=${OWNER_TELEGRAM_ID}`);
    startPolling();
    panels.start(bot.api);
  } catch (error) {
    console.error('Bot startup failed:', error);
    server.close();
    process.exit(1);
  }
})();

process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));
process.on('unhandledRejection', error => console.error('Unhandled promise rejection:', error));
process.on('uncaughtException', error => {
  console.error('Uncaught exception:', error);
  if (!shuttingDown) process.exit(1);
});
